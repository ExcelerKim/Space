from flask import (Flask,
                   render_template, # render_template_string (특수문자 걸러줌)
                   request,
                   redirect,)
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField
from wtforms.validators import DataRequired
from flask_sqlalchemy import SQLAlchemy
import os


app = Flask(__name__)
# app.config.update({'SECRET_KEY':'김형석'})
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///test.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True
db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)

    def __repr__(self):
        return '<User %r>' % self.username

class MyForm(FlaskForm):
    text = StringField('text1', validators=[DataRequired()])
    password = PasswordField('password1')

class SearchForm(FlaskForm):
    search = StringField('검색', validators=[DataRequired()])

@app.route('/add')
def add():
    user = User() #instance 화
    user.email = 'hskim6543@gmail.com'
    user.username = 'kim'
    db.session.add(user)
    # db.insert(user)
    db.session.commit()
    return render_template('index.html')

@app.route('/insert')
def insert():
    ue = request.args.get('ue') #ue: user_email
    uu = request.args.get('uu') #uu: user_username
    user = User()
    user.email = ue
    user.username = uu
    user.id = 1
    db.session.add(user)
    db.session.commit()
    return render_template('index.html')

@app.route('/')
def index():
    # a = [1,2,3,4,5,6,7,8]
    # b = list('abcdefg')
    # c = list(zip(a,b))
    # d = {'a': 1, 'b': 2, 'c': 3}
    users = User.query.all()

    return render_template('index.html', kim=users)

@app.route('/form', methods=['GET','POST'])
def form1():
    form = MyForm()
    if request.method == 'GET':
        if form.validate_on_submit():
            return render_template('index.html')
        # a = request.args.get('a','') # default 값 지정 가능
        # b = request.args['a']
        # c = request.args.a # (x)
        return render_template('form.html', form2=form)
    else:
        return render_template('form.html', form2=form)


@app.route('/form2', methods=['POST'])
def form2():
    return render_template('form.html')

@app.route('/search',methods=['POST'])
def search():
    search_term = request.form['search']
    # search_term = request.form.get('search')
    if search_term == 'kim':
        return render_template('index.html')
    return redirect('/form')

if __name__ == '__main__':
    app.run(debug=True)
# search_url = f'search.daum.net/search?f(search)'